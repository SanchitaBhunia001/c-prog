#include<stdio.h>
#include<string.h>
int main()
{
char str[10];
    printf("please enter the string:-");
    gets(str);
    puts(str);
    return 0;
}