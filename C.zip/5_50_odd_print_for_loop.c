#include<stdio.h>
void main()
{
	int i=5;
	for(i>=5;i<=50;i=i+2)
	{
		printf("%d \t",i);
	}
}
