#include<stdio.h>
int odev()
{
int x;
printf("enter the value of x");
scanf("%d",&x);
if(x%2==0)
printf("this is even");
else
printf("this is odd")
}
int main()
{
 odev();
return 0;
}

    