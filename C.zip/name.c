#include<stdio.h>
#include<string.h>
int main()
{
char str1[10],str2[10], str3[10],str4[10];
int i;
    printf("please enter the name:-");
    scanf("%s", str1);
    printf("plase enter the surname:-");
    scanf("%s", str2);
    printf("%s" "%s", str1,str2);
    return 0;
}