#include<stdio.h>
void main()
{
	int n,i;
	printf("enter the number:-");
	scanf("%d",&n);
	for(i>=0;i<=10;i++)
	{
		printf("%d \n",n*i);
	}
}
