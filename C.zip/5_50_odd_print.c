#include<stdio.h>
void main()
{
	int i=5;
	while(i<=50)
	{
		printf("%d \t",i);
		i=i+2;
	}
}
