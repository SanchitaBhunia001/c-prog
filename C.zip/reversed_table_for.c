#include<stdio.h>
void main()
{
	int n,i=10;
	printf("enter the number:-");
	scanf("%d",&n);
	for(i<=10;i>=0;i--)
	{
		printf("%d \n",n*i);
	}
}
